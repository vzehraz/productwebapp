package com.tus.ecommerce.checkoutwebapp.checkoutwebapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CheckoutwebappApplicationTests {

	@Test
	void contextLoads() {
	}

}
